#!/system/bin/sh

# if Magisk changes its mount point in the future
MODDIR=${0%/*}

# Function to write values to files
write() {
  # Bail out if the file does not exist
  [[ ! -f "$1" ]] && return 1

  # Make the file writable in case it is not already
  chmod +w "$1" 2> /dev/null

  # Write the new value and bail if there's an error
  if ! echo "$2" > "$1" 2> /dev/null; then
    echo "Failed: $1 → $2"
    echo "Failed: $1 → $2" >> /data/local/tmp/script_log.txt  # Log the error
    return 1
  fi
}

# Function to check if the screen is off
is_screen_off() {
  # Check the status of the screen using the 'dumpsys input_method' command
  screen_status=$(dumpsys input_method | grep -o 'mInteractive=false')
  if [[ -n "$screen_status" ]]; then
    return 0  # Screen is off
  else
    return 1  # Screen is on
  fi
}

# Function to set CPU governor
set_cpu_governor() {
  if is_screen_off; then
    # Screen is off, set CPU governor to power-saving
    governor="powersave"
    echo "Screen is off, setting CPU governor to $governor"
    echo "Screen is off, setting CPU governor to $governor" >> /data/local/tmp/script_log.txt  # Log the action
  else
    # Screen is on, set CPU governor to schedutil (or your preferred governor)
    governor="schedutil"
    echo "Screen is on, setting CPU governor to $governor"
    echo "Screen is on, setting CPU governor to $governor" >> /data/local/tmp/script_log.txt  # Log the action
  fi

  for policy in /sys/devices/system/cpu/cpufreq/policy*; do
    write "$policy/scaling_governor" "$governor"
  done
}

# Function to underclock the CPU when the screen is off
underclock_cpu() {
  if is_screen_off; then
    # Screen is off, underclock the CPU
    max_freq_file="/sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq"
    min_freq_file="/sys/devices/system/cpu/cpu0/cpufreq/scaling_min_freq"

    # Set the maximum and minimum CPU frequencies to your desired values
    # Example: Set both max and min frequencies to 500 MHz
    echo "500000" > "$max_freq_file"
    echo "500000" > "$min_freq_file"
    echo "Screen is off, underclocking CPU to 500 MHz"
    echo "Screen is off, underclocking CPU to 500 MHz" >> /data/local/tmp/script_log.txt  # Log the action
  fi
}

# Sync before executing to avoid crashes
sync

# Initialize the log file
echo "Script started" > /data/local/tmp/script_log.txt

# Call the function to set CPU governor
set_cpu_governor

# Call the function to underclock the CPU when the screen is off
underclock_cpu

# Pixel 3 Google Schedutil Battery-Friendly Speed Limits
# Up Rate Limits
for policy in /sys/devices/system/cpu/cpufreq/policy*; do
  write "$policy/schedutil/up_rate_limit_us" "5000"
done

# Down Rate Limits
for policy in /sys/devices/system/cpu/cpufreq/policy*; do
  write "$policy/schedutil/down_rate_limit_us" "50000"
done

# Log the script completion
echo "Script completed" >> /data/local/tmp/script_log.txt

# Exit
exit 0