#!/system/bin/sh

# if Magisk changes its mount point in the future
MODDIR=${0%/*}

# Function to write values to files
write() {
  # Bail out if file does not exist
  [[ ! -f "$1" ]] && return 1

  # Make file writable in case it is not already
  chmod +w "$1" 2> /dev/null

  # Write the new value and bail if there's an error
  if ! echo "$2" > "$1" 2> /dev/null; then
    echo "Failed: $1 → $2"
    return 1
  fi
}

# Function to set CPU governor
set_cpu_governor() {
  if [[ $(dumpsys power | grep 'mScreenOn=false') ]]; then
    # Screen is off, set CPU governor to power-saving
    governor="schedutil"
  else
    # Screen is on, set CPU governor to ondemand (or your preferred governor)
    governor="ondemand"
  fi

  for policy in /sys/devices/system/cpu/cpufreq/policy*; do
    write "$policy/scaling_governor" "$governor"
  done
}

# Function to underclock the CPU when the screen is off
underclock_cpu() {
  if [[ $(dumpsys power | grep 'mScreenOn=false') ]]; then
    # Screen is off, underclock the CPU
    max_freq_file="/sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq"
    min_freq_file="/sys/devices/system/cpu/cpu0/cpufreq/scaling_min_freq"

    # Set the maximum and minimum CPU frequencies to your desired values
    # Example: Set both max and min frequencies to 500 MHz
    echo "500000" > "$max_freq_file"
    echo "500000" > "$min_freq_file"
  fi
}

# Sync before executing to avoid crashes
sync

# Call the function to set CPU governor
set_cpu_governor

# Call the function to underclock the CPU when the screen is off
underclock_cpu

# Pixel 3 Google Schedutil Battery-Friendly Speed Limits
# Up Rate Limits
for policy in /sys/devices/system/cpu/cpufreq/policy*; do
  write "$policy/schedutil/up_rate_limit_us" "5000"
done

# Down Rate Limits
for policy in /sys/devices/system/cpu/cpufreq/policy*; do
  write "$policy/schedutil/down_rate_limit_us" "50000"
done

# Exit
exit 0
